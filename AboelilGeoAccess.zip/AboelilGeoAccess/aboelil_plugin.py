import pyodbc
import pandas as pd
import numpy as np
import geopandas as gpd
from shapely import wkt
from shapely.geometry import Point
import shutil
import os
import uuid
import base64
import json
from datetime import datetime

from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QPushButton, QFileDialog, 
                                 QLabel, QComboBox, QMessageBox, QProgressBar, 
                                 QTabWidget, QWidget, QLineEdit, QFormLayout, QApplication, QGroupBox, QHBoxLayout, QCheckBox, QAction)
from qgis.core import QgsMessageLog, Qgis, QgsProject, QgsVectorLayer, QgsVectorFileWriter, QgsCoordinateTransformContext
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon

class AboelilProTool(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Aboelil GeoAccess Sync")
        self.setGeometry(100, 100, 600, 650)
        
        self.hwid = str(uuid.getnode()) 
        self.is_pro = False
        self.secret_salt = "ABOELIL_SECURE_2026"
        self.license_file = os.path.join(os.path.expanduser('~'), 'aboelil_license.key')
        self.verify_license_on_startup()

        main_window_layout = QVBoxLayout()
        self.tabs = QTabWidget()
        
        self.tab_pull = QWidget()
        self.tab_push = QWidget()
        self.tab_license = QWidget()
        
        self.tabs.addTab(self.tab_pull, "⬇️ 1. قراءة وسحب البيانات")
        self.tabs.addTab(self.tab_push, "⬆️ 2. تحديث ورفع التعديلات")
        self.tabs.addTab(self.tab_license, "🔑 3. الترخيص والدعم")
        
        self.setup_pull_tab()
        self.setup_push_tab()
        self.setup_license_tab()
        
        main_window_layout.addWidget(self.tabs)
        
        self.progress = QProgressBar()
        main_window_layout.addWidget(self.progress)
        
        lbl_company = QLabel("Developed & Powered by:")
        lbl_company.setStyleSheet("color: #9E9E9E; font-size: 10px; text-align: center; margin-top: 10px;")
        lbl_company.setAlignment(Qt.AlignCenter)
        main_window_layout.addWidget(lbl_company)
        
        lbl_rights = QLabel("Aboelil for Smart Systems and Business Development ©")
        lbl_rights.setStyleSheet("""
            color: #455A64; 
            font-size: 13px; 
            font-weight: bold; 
            font-style: italic; 
            text-align: center; 
            letter-spacing: 0.5px;
            border-top: 1px solid #CFD8DC;
            padding-top: 8px;
            padding-bottom: 5px;
        """)
        lbl_rights.setAlignment(Qt.AlignCenter)
        main_window_layout.addWidget(lbl_rights)
        
        self.setLayout(main_window_layout)
        self.access_path = ""
        self.gpkg_path = ""

    def setup_pull_tab(self):
        layout = QVBoxLayout()
        group_access = QGroupBox("أولاً: مصدر البيانات والإعدادات (Microsoft Access)")
        group_access.setStyleSheet("QGroupBox { font-weight: bold; border: 1px solid #ccc; border-radius: 5px; margin-top: 10px; }")
        layout_access = QVBoxLayout()
        
        self.lbl_access = QLabel("ملف Access: لم يتم الاختيار")
        btn_access = QPushButton("اختيار ملف Access")
        btn_access.clicked.connect(self.select_access)
        layout_access.addWidget(btn_access)
        layout_access.addWidget(self.lbl_access)
        
        self.combo_tables = QComboBox()
        layout_access.addWidget(QLabel("اختر الجدول:"))
        layout_access.addWidget(self.combo_tables)
        
        self.chk_ignore_nulls = QCheckBox("تجاهل العملاء بدون إحداثيات جغرافية (في السحب والرفع)")
        self.chk_ignore_nulls.setChecked(True)
        self.chk_ignore_nulls.setStyleSheet("color: #D32F2F; font-weight: bold; margin-top: 10px;")
        layout_access.addWidget(self.chk_ignore_nulls)
        
        group_access.setLayout(layout_access)
        layout.addWidget(group_access)

        group_pull = QGroupBox("ثانياً: سحب البيانات للخريطة (Pull)")
        group_pull.setStyleSheet("QGroupBox { font-weight: bold; border: 1px solid #2196F3; border-radius: 5px; margin-top: 10px; }")
        layout_pull = QVBoxLayout()
        btn_pull = QPushButton("⬇️ إنشاء GeoPackage وسحب البيانات")
        btn_pull.setStyleSheet("background-color: #2196F3; color: white; padding: 12px; font-weight: bold; border-radius: 4px;")
        btn_pull.clicked.connect(self.pull_data)
        layout_pull.addWidget(btn_pull)
        self.lbl_gpkg = QLabel("ملف الحفظ: سيتم تحديده عند السحب")
        layout_pull.addWidget(self.lbl_gpkg)
        group_pull.setLayout(layout_pull)
        layout.addWidget(group_pull)
        layout.addStretch() 
        self.tab_pull.setLayout(layout)

    def setup_push_tab(self):
        layout = QVBoxLayout()
        group_map = QGroupBox("أولاً: بيئة العمل الجغرافية")
        group_map.setStyleSheet("QGroupBox { font-weight: bold; border: 1px solid #9C27B0; border-radius: 5px; margin-top: 10px; }")
        layout_map = QVBoxLayout()
        self.combo_layers = QComboBox()
        self.refresh_layers()
        layer_row = QHBoxLayout()
        layer_row.addWidget(self.combo_layers)
        btn_refresh = QPushButton(" تحديث الطبقات")
        btn_refresh.clicked.connect(self.refresh_layers)
        layer_row.addWidget(btn_refresh)
        layout_map.addLayout(layer_row)
        group_map.setLayout(layout_map)
        layout.addWidget(group_map)

        group_push = QGroupBox("ثانياً: رفع التعديلات للأكسيس")
        group_push.setStyleSheet("QGroupBox { font-weight: bold; border: 1px solid #FF9800; border-radius: 5px; margin-top: 10px; }")
        layout_push = QVBoxLayout()
        btn_push = QPushButton("⬆️ رفع وإرسال التعديلات للأكسيس (Update/Insert)")
        btn_push.setStyleSheet("background-color: #FF9800; color: white; padding: 12px; font-weight: bold; border-radius: 4px;")
        btn_push.clicked.connect(self.push_data)
        layout_push.addWidget(btn_push)
        group_push.setLayout(layout_push)
        layout.addWidget(group_push)

        group_pro = QGroupBox("ثالثاً: أدوات الجودة والتصدير المتقدمة (Pro)")
        group_pro.setStyleSheet("QGroupBox { font-weight: bold; border: 1px solid #4CAF50; border-radius: 5px; margin-top: 10px; }")
        layout_pro = QVBoxLayout()
        
        if not self.is_pro:
            layout_pro.addWidget(QLabel("🔒 هذه الأدوات تتطلب تفعيل النسخة المدفوعة."))
            
        btn_dedup = QPushButton("🧹 فحص جودة البيانات واستخراج المكررات")
        btn_dedup.setEnabled(self.is_pro)
        btn_dedup.clicked.connect(self.run_deduplication)
        layout_pro.addWidget(btn_dedup)
        
        btn_gmaps = QPushButton(" تصدير لـ خرائط جوجل (Google My Maps)")
        btn_gmaps.setStyleSheet("background-color: #0F9D58; color: white; font-weight: bold; padding: 8px;")
        btn_gmaps.setEnabled(self.is_pro)
        btn_gmaps.clicked.connect(self.export_to_kml)
        layout_pro.addWidget(btn_gmaps)
        
        api_row = QHBoxLayout()
        btn_api = QPushButton(" تصدير لـ API")
        btn_api.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold;")
        btn_api.setEnabled(self.is_pro)
        btn_api.clicked.connect(self.export_to_api)
        api_row.addWidget(btn_api)
        self.api_input = QLineEdit("https://............")
        self.api_input.setEnabled(self.is_pro)
        api_row.addWidget(self.api_input)
        layout_pro.addLayout(api_row)
        
        group_pro.setLayout(layout_pro)
        layout.addWidget(group_pro)
        self.tab_push.setLayout(layout)

    def setup_license_tab(self):
        layout = QVBoxLayout()
        form_link = "https://script.google.com/macros/s/AKfycbydG8Y2sElgVvuQpbWUtsWHJS6t6-cIyL87dS4NGSszbA3O1ocKsXVlUVfCJyLZVrv8/exec"
        lbl_form = QLabel(f'<a href="{form_link}" style="color: #2196F3; font-size: 14px; font-weight: bold; text-decoration: none;">🔗 اضغط هنا لطلب أو تفعيل كود النسخة المدفوعة</a>')
        lbl_form.setOpenExternalLinks(True) 
        lbl_form.setAlignment(Qt.AlignCenter)
        layout.addWidget(lbl_form)
        lbl_thanks = QLabel("شكراً لثقتك! سيتم مراجعة طلبك والتواصل معك عبر الواتساب لتسليم الكود خلال 24 ساعة.")
        lbl_thanks.setStyleSheet("color: #00796B; font-weight: bold; font-size: 12px; margin-bottom: 15px;")
        lbl_thanks.setAlignment(Qt.AlignCenter)
        layout.addWidget(lbl_thanks)

        group_activation = QGroupBox("بيانات التفعيل")
        form_layout = QFormLayout()
        self.lbl_hwid = QLineEdit(self.hwid)
        self.lbl_hwid.setReadOnly(True)
        form_layout.addRow("البصمة الإلكترونية (HWID):", self.lbl_hwid)
        self.input_key = QLineEdit()
        form_layout.addRow("مفتاح التفعيل:", self.input_key)
        btn_activate = QPushButton("تفعيل النسخة المدفوعة الآن")
        btn_activate.clicked.connect(self.activate_license)
        form_layout.addWidget(btn_activate)
        group_activation.setLayout(form_layout)
        layout.addWidget(group_activation)
        
        status_text = "✅ مفعلة (Enterprise Pro)" if self.is_pro else "⚠️ مجانية محدودة (مسموح بـ 50 عميل وتوقف الـ API)"
        color = "green" if self.is_pro else "orange"
        self.lbl_status = QLabel(f"حالة النسخة الحالية: {status_text}")
        self.lbl_status.setStyleSheet(f"font-weight: bold; color: {color}; font-size: 13px; margin-top: 20px;")
        self.lbl_status.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.lbl_status)
        layout.addStretch()
        self.tab_license.setLayout(layout)

    def verify_license_on_startup(self):
        if os.path.exists(self.license_file):
            with open(self.license_file, 'r') as f:
                self.check_key_validity(f.read().strip())

    def check_key_validity(self, key):
        try:
            decoded_bytes = base64.b64decode(key)
            data = json.loads(decoded_bytes.decode('utf-8'))
            if data.get('hwid') == self.hwid and data.get('salt') == self.secret_salt:
                expiry = datetime.strptime(data.get('expiry'), '%Y-%m-%d')
                if datetime.now() <= expiry:
                    self.is_pro = True
                    return True
        except: pass
        self.is_pro = False
        return False

    def activate_license(self):
        key = self.input_key.text().strip()
        if self.check_key_validity(key):
            with open(self.license_file, 'w') as f: f.write(key)
            QMessageBox.information(self, "نجاح", "تم التفعيل بنجاح! برجاء إغلاق الأداة وفتحها مرة أخرى.")
        else:
            QMessageBox.critical(self, "خطأ", "الكود غير صحيح أو منتهي الصلاحية.")

    def select_access(self):
        path, _ = QFileDialog.getOpenFileName(self, "اختر ملف Access", "", "Access (*.accdb *.mdb)")
        if path:
            self.access_path = path
            self.lbl_access.setText(f"Access: {os.path.basename(path)}")
            try:
                conn = pyodbc.connect(f'DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={path};')
                self.combo_tables.clear()
                self.combo_tables.addItems([t.table_name for t in conn.cursor().tables(tableType='TABLE')])
                conn.close()
            except Exception as e: QMessageBox.critical(self, "خطأ", str(e))

    def refresh_layers(self):
        self.combo_layers.clear()
        layers = QgsProject.instance().mapLayers().values()
        vector_layers = [layer.name() for layer in layers if layer.type() == Qgis.LayerType.Vector]
        if vector_layers: self.combo_layers.addItems(vector_layers)
        else: self.combo_layers.addItem("لا يوجد طبقات مفتوحة")

    def detect_spatial_columns(self, df):
        pairs = [('longitude', 'latitude'), ('lon', 'lat'), ('x', 'y'), ('lng', 'lat'), ('Latitude', 'Longitude')]
        for x_name, y_name in pairs:
            x_col = next((c for c in df.columns if x_name.lower() in c.lower()), None)
            y_col = next((c for c in df.columns if y_name.lower() in c.lower()), None)
            if x_col and y_col: return {'type': 'xy', 'x': x_col, 'y': y_col}
        return None

    def auto_load_layer(self, layer_name):
        layers = QgsProject.instance().mapLayersByName(layer_name)
        if not layers:
            vlayer = QgsVectorLayer(f"{self.gpkg_path}|layername={layer_name}", layer_name, "ogr")
            if vlayer.isValid(): 
                QgsProject.instance().addMapLayer(vlayer)
                self.refresh_layers()

    def check_edit_mode(self, layer_name):
        layers = QgsProject.instance().mapLayersByName(layer_name)
        if layers and layers[0].isEditable(): return True
        return False

    def sanitize_val(self, val):
        if pd.isna(val) or val == 'NULL' or str(val).strip() == '': return None
        if isinstance(val, (np.int64, np.int32)): return int(val)
        if isinstance(val, (np.float64, np.float32)): return float(val)
        return val

    def get_layer_path(self, layer_name):
        layers = QgsProject.instance().mapLayersByName(layer_name)
        if layers: return layers[0].source().split("|")[0]
        return None

    def get_gdf_from_qgis_layer(self, layer_name):
        layers = QgsProject.instance().mapLayersByName(layer_name)
        if not layers: return None
        layer = layers[0]
        field_names = [f.name() for f in layer.fields()]
        data = []
        for feat in layer.getFeatures():
            row_dict = dict(zip(field_names, feat.attributes()))
            geom = feat.geometry()
            if not geom.isNull():
                row_dict['geometry'] = wkt.loads(geom.asWkt())
            else:
                row_dict['geometry'] = None
            data.append(row_dict)
        if not data: return gpd.GeoDataFrame()
        return gpd.GeoDataFrame(data, geometry='geometry')

    def pull_data(self):
        if not self.access_path:
            QMessageBox.warning(self, "تنبيه", "اختار ملف الأكسيس الأول!")
            return
        path, _ = QFileDialog.getSaveFileName(self, "إنشاء GeoPackage جديد", "", "GeoPackage (*.gpkg)")
        if not path: return
        self.gpkg_path = path
        self.lbl_gpkg.setText(f"حفظ في: {os.path.basename(path)}")
        
        table_name = self.combo_tables.currentText()
        self.progress.setValue(10)
        QApplication.processEvents()

        try:
            conn_str = f'DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self.access_path};'
            conn = pyodbc.connect(conn_str)
            df = pd.read_sql(f"SELECT * FROM [{table_name}]", conn)
            
            if not self.is_pro and len(df) > 50:
                df = df.head(50)
                QMessageBox.warning(self, "نسخة مجانية", "تم سحب أول 50 عميل فقط!")

            spatial_info = self.detect_spatial_columns(df)
            if not spatial_info:
                QMessageBox.warning(self, "تنبيه", "مش لاقي عواميد إحداثيات (Longitude/Latitude) في الجدول!")
                conn.close()
                self.progress.setValue(0)
                return

            self.progress.setValue(50)
            x_col, y_col = spatial_info['x'], spatial_info['y']
            lon_col = x_col if 'lon' in x_col.lower() or 'x' in x_col.lower() else y_col
            lat_col = y_col if 'lat' in y_col.lower() or 'y' in y_col.lower() else x_col
            
            df['geometry'] = df.apply(lambda r: Point(r[lon_col], r[lat_col]) if pd.notnull(r[lon_col]) and pd.notnull(r[lat_col]) else None, axis=1)

            null_count_total = len(df[df['geometry'].isna()])
            if self.chk_ignore_nulls.isChecked():
                df_valid = df.dropna(subset=['geometry'])
            else:
                df_valid = df
            
            gdf = gpd.GeoDataFrame(df_valid, geometry='geometry', crs="EPSG:4326")
            gdf.to_file(self.gpkg_path, layer=table_name, driver="GPKG")
            conn.close()
            
            self.progress.setValue(100)
            self.auto_load_layer(table_name)
            
            msg = f"تم سحب {len(df_valid)} عميل بنجاح!"
            if self.chk_ignore_nulls.isChecked() and null_count_total > 0:
                msg += f"\n\ تنبيه: تم تجاهل {null_count_total} عميل في الأكسيس لأن ليس لهم إحداثيات (بناءً على طلبك)."
            QMessageBox.information(self, "نجاح", msg)
            
        except Exception as e:
            QMessageBox.critical(self, "إيرور", f"مشكلة: {str(e)}")
            self.progress.setValue(0)

    def push_data(self):
        if not self.access_path:
            QMessageBox.warning(self, "تنبيه", "اختار ملف الأكسيس الأول!")
            return
            
        layer_name = self.combo_layers.currentText()
        if layer_name == "لا يوجد طبقات مفتوحة" or layer_name == "": return
        if self.check_edit_mode(layer_name):
            QMessageBox.warning(self, "تنبيه", f"اقفل قلم التعديل لطبقة '{layer_name}' واحفظ قبل الإرسال!")
            return

        table_name = self.combo_tables.currentText()
        today_date = datetime.now().strftime("%Y-%m-%d")

        try:
            db_dir = os.path.dirname(self.access_path)
            backup_folder = os.path.join(db_dir, "Aboelil_Backups", today_date)
            if not os.path.exists(backup_folder): os.makedirs(backup_folder)
            timestamp = datetime.now().strftime("%H%M%S")
            ext = ".accdb" if ".accdb" in self.access_path else ".mdb"
            base_name = os.path.basename(self.access_path).replace(ext, "")
            backup_path = os.path.join(backup_folder, f"{base_name}_{timestamp}{ext}")
            shutil.copy2(self.access_path, backup_path)
        except: pass

        try:
            gdf = self.get_gdf_from_qgis_layer(layer_name)
            if gdf is None or gdf.empty:
                QMessageBox.warning(self, "تنبيه", "الطبقة المحددة فارغة أو كل البيانات مخفية بالفلتر. لا يوجد شيء لإرساله.")
                return

            conn_str = f'DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self.access_path};'
            conn = pyodbc.connect(conn_str)
            cursor = conn.cursor()
            
            df_access = pd.read_sql(f"SELECT * FROM [{table_name}]", conn)
            access_cols = [row.column_name for row in cursor.columns(table=table_name)]
            acc_col_map = {c.lower(): c for c in access_cols} 
            
            spatial_info = self.detect_spatial_columns(pd.DataFrame(columns=access_cols))
            id_col_acc = next((c for c in access_cols if c.lower() in ['customer_n', 'id', 'uid']), access_cols[0])
            id_col_gdf = next((c for c in gdf.columns if c.lower() == id_col_acc.lower()), None)
            
            access_dict = {}
            for _, r in df_access.iterrows():
                key = r.get(id_col_acc)
                if pd.notna(key): access_dict[key] = r.to_dict()
                
            existing_ids = set(access_dict.keys())
            sync_map = {}
            for g_col in gdf.columns:
                if g_col.lower() in acc_col_map and g_col.lower() not in ['fid', 'geometry']:
                    sync_map[g_col] = acc_col_map[g_col.lower()]
            
            inserted = 0
            updated = 0
            skipped_null_geom = 0
            skipped_null_ids = 0
            self.progress.setMaximum(len(gdf))

            for index, row in gdf.iterrows():
                self.progress.setValue(index + 1)
                QApplication.processEvents()
                
                if not id_col_gdf: continue
                row_id = self.sanitize_val(row.get(id_col_gdf))
                if row_id is None:
                    skipped_null_ids += 1
                    continue
                
                row_data = {a_col: self.sanitize_val(row[g_col]) for g_col, a_col in sync_map.items()}
                
                pt_lon, pt_lat = None, None
                if row.get('geometry') and pd.notnull(row['geometry']):
                    geom = row['geometry']
                    if geom.geom_type in ['Point', 'MultiPoint']:
                        pt_lon, pt_lat = geom.centroid.x, geom.centroid.y
                        if spatial_info and spatial_info['type'] == 'xy':
                            lon_a_col = spatial_info['x'] if 'lon' in spatial_info['x'].lower() else spatial_info['y']
                            lat_a_col = spatial_info['y'] if 'lat' in spatial_info['y'].lower() else spatial_info['x']
                            row_data[lon_a_col] = pt_lon
                            row_data[lat_a_col] = pt_lat
                
                if self.chk_ignore_nulls.isChecked() and (pt_lon is None or pt_lat is None):
                    skipped_null_geom += 1
                    continue 
                
                valid_data = {k: v for k, v in row_data.items() if v is not None}
                if not valid_data: continue
                
                if row_id in existing_ids:
                    old_data = access_dict[row_id]
                    is_changed = False
                    for k, v in valid_data.items():
                        old_v = old_data.get(k)
                        if pd.isna(v) and pd.isna(old_v): continue
                        if pd.isna(v) or pd.isna(old_v): 
                            is_changed = True; break
                        try:
                            if abs(float(v) - float(old_v)) > 1e-5: is_changed = True; break
                        except:
                            if str(v).strip() != str(old_v).strip(): is_changed = True; break
                    
                    if is_changed:
                        set_clause = ", ".join([f"[{k}] = ?" for k in valid_data.keys()])
                        values = list(valid_data.values()) + [row_id]
                        query = f"UPDATE [{table_name}] SET {set_clause} WHERE [{id_col_acc}] = ?"
                        cursor.execute(query, values)
                        updated += 1
                else:
                    cols_str = ", ".join([f"[{k}]" for k in valid_data.keys()])
                    q_marks = ", ".join(["?"] * len(valid_data))
                    values = list(valid_data.values())
                    query = f"INSERT INTO [{table_name}] ({cols_str}) VALUES ({q_marks})"
                    cursor.execute(query, values)
                    inserted += 1
            
            conn.commit()
            conn.close()
            self.progress.setValue(len(gdf))
            
            if inserted == 0 and updated == 0:
                msg = "البيانات متطابقة بالفعل (وفقاً للفلتر الحالي)، مفيش إضافات جديدة تترفع!"
                if skipped_null_ids > 0: msg += f"\ تم تجاهل {skipped_null_ids} نقطة عشان خانة (Customer_N) فاضية."
                if skipped_null_geom > 0: msg += f"\ تم تجاهل {skipped_null_geom} نقطة عشان مفهاش إحداثيات."
                QMessageBox.information(self, "مفيش جديد", msg)
            else:
                msg = f"تم التحديث بنجاح للبيانات المعروضة!\nإضافة جديد: {inserted}\nتعديل حالي: {updated}"
                if skipped_null_ids > 0: msg += f"\n\ تم تجاهل {skipped_null_ids} سجل بدون ID."
                if skipped_null_geom > 0: msg += f"\ تم تجاهل {skipped_null_geom} سجل بدون إحداثيات."
                QMessageBox.information(self, "عاش جداً", msg)
            
        except Exception as e:
            QMessageBox.critical(self, "إيرور", f"مشكلة في الرفع: {str(e)}")
            self.progress.setValue(0)

    def run_deduplication(self):
        layer_name = self.combo_layers.currentText()
        if layer_name == "لا يوجد طبقات مفتوحة" or layer_name == "": return
        try:
            gdf = self.get_gdf_from_qgis_layer(layer_name)
            if gdf is None or gdf.empty: return
            gdf['coords'] = gdf['geometry'].apply(lambda geom: f"{geom.centroid.x},{geom.centroid.y}" if geom else None)
            duplicates = gdf[gdf.duplicated('coords', keep=False)]
            if not duplicates.empty:
                QMessageBox.warning(self, "المكررات", f"لقينا {len(duplicates)} عميل متداخلين جغرافياً في نفس المكان!")
            else:
                QMessageBox.information(self, "نظيف", "الداتا للطبقة المحددة (والمفلترة) نظيفة مفهاش مكررات جغرافية.")
        except Exception as e:
            QMessageBox.critical(self, "خطأ", str(e))

    def export_to_api(self):
        layer_name = self.combo_layers.currentText()
        if layer_name == "لا يوجد طبقات مفتوحة" or layer_name == "": return
        try:
            gdf = self.get_gdf_from_qgis_layer(layer_name)
            if gdf is None or gdf.empty: return
            json_payload = gdf.to_json()
            QMessageBox.information(self, "API Export", f"تم تجهيز داتا {len(gdf)} عميل.\nجاهزة للـ Nexus.")
        except Exception as e:
            QMessageBox.critical(self, "خطأ", str(e))

    def export_to_kml(self):
        layer_name = self.combo_layers.currentText()
        if layer_name == "لا يوجد طبقات مفتوحة" or layer_name == "": 
            QMessageBox.warning(self, "تنبيه", "اختر طبقة أولاً.")
            return

        layers = QgsProject.instance().mapLayersByName(layer_name)
        if not layers: return
        layer = layers[0]

        save_path, _ = QFileDialog.getSaveFileName(self, "حفظ ملف خرائط جوجل", f"{layer_name}_GoogleMaps.kml", "KML Files (*.kml)")
        if not save_path: return

        try:
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "KML"
            options.fileEncoding = "UTF-8"
            
            error, msg = QgsVectorFileWriter.writeAsVectorFormatV2(
                layer,
                save_path,
                QgsProject.instance().transformContext(),
                options
            )
            
            if error == QgsVectorFileWriter.NoError:
                link = "https://mymaps.google.com/"
                msg_box = QMessageBox()
                msg_box.setIcon(QMessageBox.Information)
                msg_box.setWindowTitle("تم التصدير بنجاح ")
                msg_box.setText(f"تم إنشاء ملف KML بنجاح جاهز للرفع على خرائط جوجل:\n{save_path}")
                msg_box.setInformativeText(f'<a href="{link}" style="color: #0F9D58; font-size: 14px; font-weight: bold; text-decoration: none;">🔗 اضغط هنا لفتح Google My Maps ورفع الملف</a>')
                msg_box.setTextFormat(Qt.RichText)
                msg_box.setOpenExternalLinks(True)
                msg_box.exec_()
            else:
                QMessageBox.critical(self, "خطأ", f"حدث خطأ أثناء الحفظ: {msg}")
        except Exception as e:
            QMessageBox.critical(self, "خطأ", str(e))

class AboelilPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.action = QAction(QIcon(icon_path), "Aboelil GeoAccess Sync", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Aboelil Tools", self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("&Aboelil Tools", self.action)

    def run(self):
        if not self.dialog:
            self.dialog = AboelilProTool()
        self.dialog.show()