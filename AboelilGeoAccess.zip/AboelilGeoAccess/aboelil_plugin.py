import os
import sys

# استيراد المكتبات الأساسية لبرنامج QGIS (دائماً موجودة)
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QIcon

# =========================================================
# 1. نظام الفحص الذكي (لمنع إيرور classFactory)
# =========================================================
IMPORT_ERROR = None
try:
    import pyodbc
    import pandas as pd
    import numpy as np
    import geopandas as gpd
    from shapely import wkt
    from shapely.geometry import Point
    import shutil
    import uuid
    import base64
    import json
    import urllib.request
    from datetime import datetime

    from qgis.PyQt.QtWidgets import (
        QDialog,
        QVBoxLayout,
        QPushButton,
        QFileDialog,
        QLabel,
        QComboBox,
        QProgressBar,
        QTabWidget,
        QWidget,
        QLineEdit,
        QFormLayout,
        QApplication,
        QGroupBox,
        QHBoxLayout,
        QCheckBox,
    )
    from qgis.core import (
        QgsMessageLog,
        Qgis,
        QgsProject,
        QgsVectorLayer,
        QgsVectorFileWriter,
        QgsSettings,
    )
    from qgis.PyQt.QtCore import Qt
except Exception as e:
    IMPORT_ERROR = str(e)


# =========================================================
# 2. كلاس الإضافة الرئيسي (يظهر دائماً في البرنامج)
# =========================================================
class AboelilPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        self.action = QAction(
            QIcon(icon_path), "Aboelil GeoAccess Sync", self.iface.mainWindow()
        )
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Aboelil Tools", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Aboelil Tools", self.action)

    def run(self):
        # لو في مكتبة ناقصة، نعرض رسالة شيك بدل ما البرنامج يكراش
        if IMPORT_ERROR:
            QMessageBox.critical(
                self.iface.mainWindow(),
                "⚠️ مكتبات مفقودة",
                f"لم تفتح الأداة بسبب نقص في بعض مكتبات بايثون على جهازك.\n\nالخطأ البرمجي:\n{IMPORT_ERROR}\n\n"
                "💡 الحل: افتح برنامج (OSGeo4W Shell) من قائمة Start في الويندوز، واكتب الأمر التالي لتسطيب النواقص:\n\n"
                "python -m pip install pyodbc pandas geopandas shapely openpyxl",
            )
            return

        # لو كل المكتبات موجودة، افتح الأداة
        self.dialog = AboelilProTool()
        self.dialog.show()


# =========================================================
# 3. الواجهة الرئيسية للأداة (لا يتم تعريفها إلا لو المكتبات موجودة)
# =========================================================
if not IMPORT_ERROR:

    class AboelilProTool(QDialog):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Aboelil GeoAccess Sync - Enterprise 🌟")
            self.setGeometry(100, 100, 600, 700)

            # نظام التراخيص
            self.hwid = str(uuid.getnode())
            self.is_pro = False
            self.secret_salt = "ABOELIL_SECURE_2026"
            self.license_file = os.path.join(
                os.path.expanduser("~"), "aboelil_license.key"
            )
            self.google_api_url = "حط_لينك_الـ_API_بتاع_جوجل_هنا"

            self.verify_online_license()

            # بناء الواجهة
            main_window_layout = QVBoxLayout()
            self.tabs = QTabWidget()

            self.tab_pull = QWidget()
            self.tab_push = QWidget()
            self.tab_tools = QWidget()
            self.tab_license = QWidget()

            self.setup_pull_tab()
            self.setup_push_tab()
            self.setup_tools_tab()
            self.setup_license_tab()

            self.tabs.addTab(self.tab_pull, "⬇️ 1. قراءة وسحب")
            self.tabs.addTab(self.tab_push, "⬆️ 2. تحديث ورفع")
            self.tabs.addTab(self.tab_tools, "🚀 3. أدوات التصدير")
            self.tabs.addTab(self.tab_license, "🔐 4. الترخيص")

            main_window_layout.addWidget(self.tabs)

            self.progress = QProgressBar()
            main_window_layout.addWidget(self.progress)

            self.refresh_layers()

            # حقوق الشركة
            lbl_company = QLabel("Developed & Powered by:")
            lbl_company.setStyleSheet(
                "color: #9E9E9E; font-size: 10px; text-align: center; margin-top: 10px;"
            )
            lbl_company.setAlignment(Qt.AlignCenter)
            main_window_layout.addWidget(lbl_company)

            lbl_rights = QLabel("Aboelil for Smart Systems and Business Development ©")
            lbl_rights.setStyleSheet(
                "color: #455A64; font-size: 13px; font-weight: bold; font-style: italic; text-align: center; border-top: 1px solid #CFD8DC; padding-top: 8px;"
            )
            lbl_rights.setAlignment(Qt.AlignCenter)
            main_window_layout.addWidget(lbl_rights)

            self.setLayout(main_window_layout)
            self.access_path = ""
            self.gpkg_path = ""

        # ================= 1. تبويب السحب والإكسيل =================
        def setup_pull_tab(self):
            layout = QVBoxLayout()
            group_access = QGroupBox("أولاً: مصدر البيانات (Access)")
            group_access.setStyleSheet(
                "QGroupBox { font-weight: bold; border: 1px solid #ccc; border-radius: 5px; margin-top: 10px; }"
            )
            layout_access = QVBoxLayout()
            self.lbl_access = QLabel("ملف Access: لم يتم الاختيار")
            btn_access = QPushButton("اختيار ملف Access")
            btn_access.clicked.connect(self.select_access)
            layout_access.addWidget(btn_access)
            layout_access.addWidget(self.lbl_access)
            self.combo_tables = QComboBox()
            layout_access.addWidget(QLabel("اختر الجدول:"))
            layout_access.addWidget(self.combo_tables)
            self.chk_ignore_nulls = QCheckBox("تجاهل العملاء بدون إحداثيات جغرافية")
            self.chk_ignore_nulls.setChecked(True)
            self.chk_ignore_nulls.setStyleSheet("color: #D32F2F; font-weight: bold;")
            layout_access.addWidget(self.chk_ignore_nulls)
            group_access.setLayout(layout_access)
            layout.addWidget(group_access)

            group_pull = QGroupBox("ثانياً: سحب البيانات للخريطة")
            group_pull.setStyleSheet(
                "QGroupBox { font-weight: bold; border: 1px solid #2196F3; border-radius: 5px; margin-top: 10px; }"
            )
            layout_pull = QVBoxLayout()

            btn_pull = QPushButton("⬇️ إنشاء GeoPackage وسحب من Access")
            btn_pull.setStyleSheet(
                "background-color: #2196F3; color: white; padding: 10px; font-weight: bold; border-radius: 4px;"
            )
            btn_pull.clicked.connect(self.pull_data)
            layout_pull.addWidget(btn_pull)

            self.lbl_gpkg = QLabel("ملف الحفظ (GPKG): سيتم تحديده عند السحب")
            layout_pull.addWidget(self.lbl_gpkg)

            btn_excel = QPushButton("📊 إضافة بيانات من شيت Excel للـ GeoPackage")
            btn_excel.setStyleSheet(
                "background-color: #4CAF50; color: white; padding: 10px; font-weight: bold; border-radius: 4px; margin-top: 10px;"
            )
            btn_excel.clicked.connect(self.import_excel_data)
            layout_pull.addWidget(btn_excel)

            group_pull.setLayout(layout_pull)
            layout.addWidget(group_pull)
            layout.addStretch()
            self.tab_pull.setLayout(layout)

        # ================= 2. تبويب الرفع =================
        def setup_push_tab(self):
            layout = QVBoxLayout()
            group_map = QGroupBox("أولاً: بيئة العمل الجغرافية")
            layout_map = QVBoxLayout()
            self.combo_layers_push = QComboBox()
            layer_row = QHBoxLayout()
            layer_row.addWidget(self.combo_layers_push)
            btn_refresh = QPushButton("🔄 تحديث")
            btn_refresh.clicked.connect(self.refresh_layers)
            layer_row.addWidget(btn_refresh)
            layout_map.addLayout(layer_row)
            group_map.setLayout(layout_map)
            layout.addWidget(group_map)

            group_push = QGroupBox("ثانياً: رفع التعديلات للأكسيس")
            layout_push = QVBoxLayout()
            btn_push = QPushButton("⬆️ رفع وإرسال التعديلات (Update/Insert)")
            btn_push.setStyleSheet(
                "background-color: #FF9800; color: white; padding: 12px; font-weight: bold; border-radius: 4px;"
            )
            btn_push.clicked.connect(self.push_data)
            layout_push.addWidget(btn_push)
            group_push.setLayout(layout_push)
            layout.addWidget(group_push)
            layout.addStretch()
            self.tab_push.setLayout(layout)

        # ================= 3. أدوات التصدير =================
        def setup_tools_tab(self):
            layout = QVBoxLayout()
            group_map = QGroupBox("أولاً: اختر الطبقة")
            layout_map = QVBoxLayout()
            self.combo_layers_tools = QComboBox()
            layout_map.addWidget(self.combo_layers_tools)
            group_map.setLayout(layout_map)
            layout.addWidget(group_map)

            group_pro = QGroupBox("ثانياً: أدوات التصدير والمراجعة")
            layout_pro = QVBoxLayout()

            btn_gmaps = QPushButton("🗺️ تصدير لـ خرائط جوجل (Google My Maps)")
            btn_gmaps.setStyleSheet(
                "background-color: #0F9D58; color: white; font-weight: bold; padding: 12px;"
            )
            btn_gmaps.clicked.connect(self.export_to_kml)
            layout_pro.addWidget(btn_gmaps)

            btn_dedup = QPushButton("🧹 فحص جودة البيانات واستخراج المكررات")
            btn_dedup.setEnabled(self.is_pro)
            btn_dedup.clicked.connect(self.run_deduplication)
            layout_pro.addWidget(btn_dedup)

            api_row = QHBoxLayout()
            btn_api = QPushButton("🌐 API Nexus")
            btn_api.setEnabled(self.is_pro)
            api_row.addWidget(btn_api)
            self.api_input = QLineEdit("https://script.google.com/macros/...")
            self.api_input.setEnabled(self.is_pro)
            api_row.addWidget(self.api_input)
            layout_pro.addLayout(api_row)

            group_pro.setLayout(layout_pro)
            layout.addWidget(group_pro)
            layout.addStretch()
            self.tab_tools.setLayout(layout)

        # ================= 4. الترخيص =================
        def setup_license_tab(self):
            layout = QVBoxLayout()
            form_link = "https://forms.gle/if45RvtTpNuFw2Rj7"
            lbl_form = QLabel(
                f'<a href="{form_link}" style="color: #2196F3; font-size: 14px; font-weight: bold; text-decoration: none;">📋 طلب كود التفعيل (Google Form)</a>'
            )
            lbl_form.setOpenExternalLinks(True)
            lbl_form.setAlignment(Qt.AlignCenter)
            layout.addWidget(lbl_form)

            group_activation = QGroupBox("بيانات التفعيل")
            form_layout = QFormLayout()
            self.lbl_hwid = QLineEdit(self.hwid)
            self.lbl_hwid.setReadOnly(True)
            form_layout.addRow("HWID:", self.lbl_hwid)

            btn_activate = QPushButton("تحقق من السيرفر وتفعيل Pro")
            btn_activate.setStyleSheet(
                "background-color: #607D8B; color: white; font-weight: bold;"
            )
            btn_activate.clicked.connect(self.check_online_activation)
            form_layout.addWidget(btn_activate)
            group_activation.setLayout(form_layout)
            layout.addWidget(group_activation)

            status_text = "✅ مفعلة (Pro)" if self.is_pro else "⚠️ مجانية محدودة"
            color = "green" if self.is_pro else "orange"
            self.lbl_status = QLabel(f"الحالة الحالية: {status_text}")
            self.lbl_status.setStyleSheet(
                f"font-weight: bold; color: {color}; font-size: 14px; margin-top: 10px;"
            )
            self.lbl_status.setAlignment(Qt.AlignCenter)
            layout.addWidget(self.lbl_status)
            layout.addStretch()
            self.tab_license.setLayout(layout)

        # ================= الدوال التقنية =================
        def verify_online_license(self):
            try:
                if "حط_لينك" in self.google_api_url:
                    return
                url = f"{self.google_api_url}?hwid={self.hwid}"
                req = urllib.request.urlopen(url, timeout=5)
                res = json.loads(req.read().decode())
                if res.get("status") == "active":
                    self.is_pro = True
                    return
            except:
                pass
            self.verify_offline_license()

        def verify_offline_license(self):
            if os.path.exists(self.license_file):
                with open(self.license_file, "r") as f:
                    try:
                        data = json.loads(
                            base64.b64decode(f.read().strip()).decode("utf-8")
                        )
                        if (
                            data.get("hwid") == self.hwid
                            and data.get("salt") == self.secret_salt
                        ):
                            if datetime.now() <= datetime.strptime(
                                data.get("expiry"), "%Y-%m-%d"
                            ):
                                self.is_pro = True
                    except:
                        pass

        def check_online_activation(self):
            self.verify_online_license()
            if self.is_pro:
                QMessageBox.information(self, "نجاح", "تم التفعيل من السيرفر بنجاح!")
                self.lbl_status.setText("الحالة الحالية: ✅ مفعلة (Pro)")
                self.lbl_status.setStyleSheet(
                    "font-weight: bold; color: green; font-size: 14px;"
                )
            else:
                QMessageBox.warning(
                    self, "فشل", "هذا الجهاز غير مسجل أو منتهي الصلاحية على السيرفر."
                )

        def refresh_layers(self):
            if hasattr(self, "combo_layers_push"):
                self.combo_layers_push.clear()
                self.combo_layers_tools.clear()
                layers = QgsProject.instance().mapLayers().values()
                vector_layers = [
                    layer.name()
                    for layer in layers
                    if layer.type() == Qgis.LayerType.Vector
                ]
                if vector_layers:
                    self.combo_layers_push.addItems(vector_layers)
                    self.combo_layers_tools.addItems(vector_layers)
                else:
                    self.combo_layers_push.addItem("لا يوجد طبقات مفتوحة")
                    self.combo_layers_tools.addItem("لا يوجد طبقات مفتوحة")

        def select_access(self):
            path, _ = QFileDialog.getOpenFileName(
                self, "اختر ملف Access", "", "Access (*.accdb *.mdb)"
            )
            if path:
                self.access_path = path
                self.lbl_access.setText(f"Access: {os.path.basename(path)}")
                try:
                    conn = pyodbc.connect(
                        f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={path};"
                    )
                    self.combo_tables.clear()
                    self.combo_tables.addItems(
                        [t.table_name for t in conn.cursor().tables(tableType="TABLE")]
                    )
                    conn.close()
                except Exception as e:
                    QMessageBox.critical(self, "خطأ", str(e))

        def detect_spatial_columns(self, df):
            pairs = [
                ("longitude", "latitude"),
                ("lon", "lat"),
                ("x", "y"),
                ("lng", "lat"),
                ("Latitude", "Longitude"),
            ]
            for x_name, y_name in pairs:
                x_col = next(
                    (c for c in df.columns if x_name.lower() in c.lower()), None
                )
                y_col = next(
                    (c for c in df.columns if y_name.lower() in c.lower()), None
                )
                if x_col and y_col:
                    return {"type": "xy", "x": x_col, "y": y_col}
            return None

        def auto_load_layer(self, layer_name):
            layers = QgsProject.instance().mapLayersByName(layer_name)
            if not layers:
                vlayer = QgsVectorLayer(
                    f"{self.gpkg_path}|layername={layer_name}", layer_name, "ogr"
                )
                if vlayer.isValid():
                    QgsProject.instance().addMapLayer(vlayer)
                    self.refresh_layers()

        def check_edit_mode(self, layer_name):
            layers = QgsProject.instance().mapLayersByName(layer_name)
            if layers and layers[0].isEditable():
                return True
            return False

        def get_gdf_from_qgis_layer(self, layer_name):
            layers = QgsProject.instance().mapLayersByName(layer_name)
            if not layers:
                return None
            layer = layers[0]
            field_names = [f.name() for f in layer.fields()]
            data = []
            for feat in layer.getFeatures():
                row_dict = dict(zip(field_names, feat.attributes()))
                geom = feat.geometry()
                row_dict["geometry"] = (
                    wkt.loads(geom.asWkt()) if not geom.isNull() else None
                )
                data.append(row_dict)
            return (
                gpd.GeoDataFrame(data, geometry="geometry")
                if data
                else gpd.GeoDataFrame()
            )

        def pull_data(self):
            if not self.access_path:
                QMessageBox.warning(self, "تنبيه", "برجاء اختيار ملف الأكسيس أولاً.")
                return
            path, _ = QFileDialog.getSaveFileName(
                self, "حفظ GeoPackage", "", "GeoPackage (*.gpkg)"
            )
            if not path:
                return
            self.gpkg_path = path
            table_name = self.combo_tables.currentText()
            self.progress.setValue(10)
            try:
                conn = pyodbc.connect(
                    f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self.access_path};"
                )
                df = pd.read_sql(f"SELECT * FROM [{table_name}]", conn)

                spatial_info = self.detect_spatial_columns(df)
                if spatial_info:
                    x_col, y_col = spatial_info["x"], spatial_info["y"]
                    df[x_col] = pd.to_numeric(df[x_col], errors="coerce")
                    df[y_col] = pd.to_numeric(df[y_col], errors="coerce")
                    df["geometry"] = df.apply(
                        lambda r: (
                            Point(r[x_col], r[y_col])
                            if pd.notnull(r[x_col]) and pd.notnull(r[y_col])
                            else None
                        ),
                        axis=1,
                    )

                    df_final = (
                        df.dropna(subset=["geometry"])
                        if self.chk_ignore_nulls.isChecked()
                        else df
                    )
                    gdf = gpd.GeoDataFrame(
                        df_final, geometry="geometry", crs="EPSG:4326"
                    )
                    gdf.to_file(self.gpkg_path, layer=table_name, driver="GPKG")

                    self.progress.setValue(100)
                    self.auto_load_layer(table_name)
                    QMessageBox.information(
                        self, "نجاح", f"تم سحب {len(df_final)} سجل."
                    )
                conn.close()
            except Exception as e:
                QMessageBox.critical(self, "خطأ", f"مشكلة: {str(e)}")

        def import_excel_data(self):
            if not self.gpkg_path:
                QMessageBox.warning(
                    self, "تنبيه", "يجب إنشاء أو سحب ملف GeoPackage أولاً."
                )
                return

            excel_path, _ = QFileDialog.getOpenFileName(
                self, "اختر ملف Excel", "", "Excel Files (*.xlsx *.xls)"
            )
            if not excel_path:
                return

            self.progress.setValue(20)
            QApplication.processEvents()

            try:
                df = pd.read_excel(excel_path)
                spatial_info = self.detect_spatial_columns(df)

                if not spatial_info:
                    QMessageBox.warning(
                        self,
                        "تنبيه",
                        "لم نتمكن من العثور على الإحداثيات في ملف الإكسيل.",
                    )
                    self.progress.setValue(0)
                    return

                self.progress.setValue(50)
                x_col, y_col = spatial_info["x"], spatial_info["y"]
                df[x_col] = pd.to_numeric(df[x_col], errors="coerce")
                df[y_col] = pd.to_numeric(df[y_col], errors="coerce")

                df["geometry"] = df.apply(
                    lambda r: (
                        Point(r[x_col], r[y_col])
                        if pd.notnull(r[x_col]) and pd.notnull(r[y_col])
                        else None
                    ),
                    axis=1,
                )
                df_valid = df.dropna(subset=["geometry"])

                if df_valid.empty:
                    QMessageBox.warning(
                        self, "تنبيه", "الإكسيل لا يحتوي على إحداثيات صحيحة."
                    )
                    self.progress.setValue(0)
                    return

                gdf = gpd.GeoDataFrame(df_valid, geometry="geometry", crs="EPSG:4326")
                layer_name = os.path.splitext(os.path.basename(excel_path))[0]
                gdf.to_file(self.gpkg_path, layer=layer_name, driver="GPKG")

                self.progress.setValue(100)
                self.auto_load_layer(layer_name)
                QMessageBox.information(
                    self, "نجاح", f"تم استيراد {len(df_valid)} عميل من الإكسيل بنجاح!"
                )

            except Exception as e:
                QMessageBox.critical(self, "إيرور", f"مشكلة في قراءة الإكسيل: {str(e)}")
                self.progress.setValue(0)

        def push_data(self):
            if not self.access_path:
                QMessageBox.warning(self, "تنبيه", "اختار ملف الأكسيس أولاً!")
                return
            layer_name = self.combo_layers_push.currentText()
            if layer_name == "لا يوجد طبقات مفتوحة":
                return

            layers = QgsProject.instance().mapLayersByName(layer_name)
            if layers and layers[0].isEditable():
                QMessageBox.warning(self, "تنبيه", "اقفل قلم التعديل أولاً!")
                return

            table_name = self.combo_tables.currentText()
            try:
                gdf = self.get_gdf_from_qgis_layer(layer_name)
                if gdf is None or gdf.empty:
                    return
                conn = pyodbc.connect(
                    f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self.access_path};"
                )
                df_acc = pd.read_sql(f"SELECT * FROM [{table_name}]", conn)
                id_col = next(
                    (c for c in df_acc.columns if c.lower() in ["customer_n", "id"]),
                    df_acc.columns[0],
                )
                acc_data = {
                    str(r[id_col]): r.to_dict()
                    for _, r in df_acc.iterrows()
                    if pd.notna(r[id_col])
                }

                cursor = conn.cursor()
                inserted = updated = 0
                for _, row in gdf.iterrows():
                    row_id = str(row.get(id_col, ""))
                    if row_id == "None" or not row_id:
                        continue

                    geom = row["geometry"]
                    lat = lon = None
                    if geom:
                        lon, lat = geom.centroid.x, geom.centroid.y
                    if self.chk_ignore_nulls.isChecked() and not geom:
                        continue

                    if row_id in acc_data:
                        cursor.execute(
                            f"UPDATE [{table_name}] SET Latitude=?, Longitude=? WHERE [{id_col}]=?",
                            (lat, lon, row_id),
                        )
                        updated += 1
                    else:
                        cursor.execute(
                            f"INSERT INTO [{table_name}] ([{id_col}], Latitude, Longitude) VALUES (?, ?, ?)",
                            (row_id, lat, lon),
                        )
                        inserted += 1
                conn.commit()
                conn.close()
                QMessageBox.information(
                    self, "نجاح", f"تم التحديث!\nإضافة: {inserted}\nتعديل: {updated}"
                )
            except Exception as e:
                QMessageBox.critical(self, "إيرور", str(e))

        def export_to_kml(self):
            layer_name = self.combo_layers_tools.currentText()
            layers = QgsProject.instance().mapLayersByName(layer_name)
            if layers:
                path, _ = QFileDialog.getSaveFileName(
                    self, "حفظ KML", "", "KML (*.kml)"
                )
                if path:
                    QgsVectorFileWriter.writeAsVectorFormatV2(
                        layers[0],
                        path,
                        QgsProject.instance().transformContext(),
                        QgsVectorFileWriter.SaveVectorOptions(),
                    )
                    link = "https://www.google.com/maps/d/"
                    msg_box = QMessageBox(self)
                    msg_box.setWindowTitle("نجاح")
                    msg_box.setText("تم التصدير لجوجل مابس.")
                    msg_box.setInformativeText(
                        f'<a href="{link}">اضغط هنا لفتح الموقع</a>'
                    )
                    msg_box.exec_()

        def run_deduplication(self):
            QMessageBox.information(self, "جودة", "تعمل في النسخة المدفوعة.")
