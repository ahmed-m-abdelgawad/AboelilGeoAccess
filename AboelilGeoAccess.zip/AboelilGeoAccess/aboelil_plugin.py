import urllib.request
import threading
import subprocess
import sys
import os
import random

def auto_install_requirements():
    required_packages = ["pyodbc", "pandas", "geopandas", "shapely", "openpyxl"]
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing_packages.append(package)
    if missing_packages:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing_packages)
        except Exception:
            pass

auto_install_requirements()

import pyodbc
import pandas as pd
import numpy as np
import geopandas as gpd
from shapely import wkt
from shapely.geometry import Point
import shutil
import base64
import json
from datetime import datetime

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QPushButton, QFileDialog, QLabel, QComboBox,
    QMessageBox, QProgressBar, QTabWidget, QWidget, QLineEdit,
    QFormLayout, QApplication, QGroupBox, QHBoxLayout, QCheckBox, QAction,
    QScrollArea
)
from qgis.core import (
    QgsMessageLog, Qgis, QgsProject, QgsVectorLayer,
    QgsVectorFileWriter, QgsCoordinateTransformContext, NULL,
    QgsFeature, QgsGeometry, QgsPointXY, QgsSettings,
    QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsSymbol
)
from qgis.gui import QgsProjectionSelectionWidget
from qgis.PyQt.QtCore import Qt, QDate, QDateTime, QThread, pyqtSignal, QTimer
from qgis.PyQt.QtGui import QColor

# ==========================================
# دالة جلب البصمة الثابتة (Motherboard UUID)
# ==========================================
def get_stable_hwid():
    try:
        # يجلب الرقم التسلسلي للوحة الأم (مستحيل يتغير)
        result = subprocess.check_output('wmic csproduct get uuid', shell=True).decode().split('\n')[1].strip()
        if result: return result
    except: pass
    import uuid
    return str(uuid.getnode())

# ==========================================
# الخيط الخلفي (QThread) لمنع تجميد الشاشة
# ==========================================
class ExecuteDBWorker(QThread):
    progress_sig = pyqtSignal(int)
    finished_sig = pyqtSignal(bool, str)

    def __init__(self, db_path, table, pk, updates, inserts, deletes):
        super().__init__()
        self.db_path = db_path
        self.table = table
        self.pk = pk
        self.updates = updates
        self.inserts = inserts
        self.deletes = deletes

    def run(self):
        try:
            conn_str = f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self.db_path};"
            conn = pyodbc.connect(conn_str)
            cursor = conn.cursor()

            if self.updates:
                self.progress_sig.emit(20)
                cursor.executemany(f"UPDATE [{self.table}] SET Latitude=?, Longitude=? WHERE [{self.pk}]=?", self.updates)
            
            if self.inserts:
                self.progress_sig.emit(50)
                cursor.executemany(f"INSERT INTO [{self.table}] ([{self.pk}], Latitude, Longitude) VALUES (?, ?, ?)", self.inserts)
                
            if self.deletes:
                self.progress_sig.emit(80)
                cursor.executemany(f"DELETE FROM [{self.table}] WHERE [{self.pk}]=?", self.deletes)

            conn.commit()
            conn.close()
            self.progress_sig.emit(100)
            self.finished_sig.emit(True, "تم تنفيذ العمليات بنجاح.")
        except Exception as e:
            self.finished_sig.emit(False, str(e))

# ==========================================
# كلاس الإضافة الرئيسي
# ==========================================
class AboelilPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dialog = None

    def initGui(self):
        self.action = QAction("Aboelil GeoAccess Sync V3", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Aboelil Tools", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Aboelil Tools", self.action)

    def run(self):
        if not self.dialog:
            self.dialog = AboelilProTool()
        self.dialog.show()

# ==========================================
# الواجهة الرئيسية V3.0 Ultimate
# ==========================================
class AboelilProTool(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Aboelil GeoAccess Sync - Enterprise V3.0 🌟")
        self.setGeometry(100, 100, 750, 800)
        
        # ضبط الاتجاه ليكون من اليمين لليسار (RTL) لدعم اللغة العربية بشكل مثالي
        self.setLayoutDirection(Qt.RightToLeft)

        # الحماية والتراخيص بالـ HWID الثابت
        self.hwid = get_stable_hwid()
        self.is_pro = False
        self.secret_salt = "ABOELIL_SECURE_2026"
        self.license_file = os.path.join(os.path.expanduser("~"), "aboelil_license.key")
        self.google_api_url = "https://script.google.com/macros/s/AKfycbydG8Y2sElgVvuQpbWUtsWHJS6t6-cIyL87dS4NGSszbA3O1ocKsXVlUVfCJyLZVrv8/exec"
        self.verify_online_license()

        self.settings = QgsSettings()
        self.pull_access_path = self.settings.value("Aboelil/pull_path", "")
        self.push_access_path = self.settings.value("Aboelil/push_path", "")
        
        self.current_excel_df = None
        self.mapping_combos = {}

        # مؤقت المزامنة التلقائية
        self.auto_sync_timer = QTimer()
        self.auto_sync_timer.timeout.connect(self.perform_silent_sync)

        # بناء التابات
        main_layout = QVBoxLayout()
        self.tabs = QTabWidget()

        self.tab_pull = QWidget()
        self.tab_excel = QWidget()
        self.tab_push = QWidget()
        self.tab_auto = QWidget() # تابة الأتمتة
        self.tab_tools = QWidget()
        self.tab_license = QWidget()

        self.setup_pull_tab()
        self.setup_excel_tab()
        self.setup_push_tab()
        self.setup_auto_tab()
        self.setup_tools_tab()
        self.setup_license_tab()

        self.tabs.addTab(self.tab_pull, "1. سحب من Access")
        self.tabs.addTab(self.tab_excel, "2. دمج Excel")
        self.tabs.addTab(self.tab_push, "3. مزامنة ورفع")
        self.tabs.addTab(self.tab_auto, "4. أتمتة (Auto-Sync)")
        self.tabs.addTab(self.tab_tools, "5. أدوات وصحة البيانات")
        self.tabs.addTab(self.tab_license, "6. الترخيص")

        main_layout.addWidget(self.tabs)
        self.progress = QProgressBar()
        main_layout.addWidget(self.progress)

        lbl_rights = QLabel("Developed & Powered by:\nAboelil for Smart Systems and Business Development ©")
        lbl_rights.setStyleSheet("color: #455A64; font-size: 12px; font-weight: bold; text-align: center; padding-top: 5px;")
        lbl_rights.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(lbl_rights)

        self.setLayout(main_layout)

    # --- 1. تبويب السحب ---
    def setup_pull_tab(self):
        layout = QVBoxLayout()
        
        grp_access = QGroupBox("مصدر بيانات Access (Pull)")
        vbox_acc = QVBoxLayout()
        
        row_acc = QHBoxLayout()
        acc_name = os.path.basename(self.pull_access_path) if self.pull_access_path else "لم يتم الاختيار"
        self.lbl_pull_acc = QLabel(acc_name)
        btn_sel_acc = QPushButton("اختيار قاعدة البيانات")
        btn_sel_acc.clicked.connect(lambda: self.select_access_file('pull'))
        row_acc.addWidget(btn_sel_acc)
        row_acc.addWidget(self.lbl_pull_acc)
        vbox_acc.addLayout(row_acc)

        row_tbl = QHBoxLayout()
        self.combo_pull_tables = QComboBox()
        row_tbl.addWidget(QLabel("الجدول:"))
        row_tbl.addWidget(self.combo_pull_tables)
        btn_summary = QPushButton("عرض تفاصيل الحقول")
        btn_summary.clicked.connect(self.show_table_summary)
        row_tbl.addWidget(btn_summary)
        vbox_acc.addLayout(row_tbl)
        
        # اختيار الإحداثيات الشامل باستخدام ويدجت QGIS
        row_crs = QHBoxLayout()
        row_crs.addWidget(QLabel("نظام الإحداثيات (CRS):"))
        self.crs_selector = QgsProjectionSelectionWidget()
        row_crs.addWidget(self.crs_selector)
        vbox_acc.addLayout(row_crs)

        self.chk_ignore_nulls = QCheckBox("تجاهل السجلات بدون إحداثيات")
        self.chk_ignore_nulls.setChecked(True)
        vbox_acc.addWidget(self.chk_ignore_nulls)
        
        btn_pull = QPushButton("سحب البيانات إلى GeoPackage جديد")
        btn_pull.setStyleSheet("background-color: #2196F3; color: white; font-weight: bold; padding: 12px;")
        btn_pull.clicked.connect(self.pull_data)
        vbox_acc.addWidget(btn_pull)
        
        grp_access.setLayout(vbox_acc)
        layout.addWidget(grp_access)
        layout.addStretch()
        self.tab_pull.setLayout(layout)

    # --- 2. تبويب الإكسيل والمطابقة ---
    def setup_excel_tab(self):
        layout = QVBoxLayout()
        grp_target = QGroupBox("1. اختيار الطبقة المفتوحة")
        vbox_target = QVBoxLayout()
        row_tgt = QHBoxLayout()
        self.combo_excel_target = QComboBox()
        btn_ref_exc = QPushButton("تحديث")
        btn_ref_exc.clicked.connect(self.refresh_layers)
        row_tgt.addWidget(QLabel("الطبقة الهدف:"))
        row_tgt.addWidget(self.combo_excel_target)
        row_tgt.addWidget(btn_ref_exc)
        vbox_target.addLayout(row_tgt)
        grp_target.setLayout(vbox_target)
        layout.addWidget(grp_target)

        grp_load = QGroupBox("2. تحميل ملف Excel والمطابقة")
        vbox_load = QVBoxLayout()
        btn_load_excel = QPushButton("اختيار ملف Excel وفتح شاشة المطابقة")
        btn_load_excel.setStyleSheet("background-color: #607D8B; color: white; font-weight: bold; padding: 8px;")
        btn_load_excel.clicked.connect(self.load_excel_for_mapping)
        vbox_load.addWidget(btn_load_excel)
        
        self.mapping_scroll = QScrollArea()
        self.mapping_scroll.setWidgetResizable(True)
        self.mapping_widget = QWidget()
        self.mapping_layout = QFormLayout()
        self.mapping_widget.setLayout(self.mapping_layout)
        self.mapping_scroll.setWidget(self.mapping_widget)
        vbox_load.addWidget(self.mapping_scroll)

        self.btn_execute_excel = QPushButton("تنفيذ الدمج الآن")
        self.btn_execute_excel.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; padding: 12px;")
        self.btn_execute_excel.setEnabled(False)
        self.btn_execute_excel.clicked.connect(self.execute_excel_import)
        vbox_load.addWidget(self.btn_execute_excel)
        grp_load.setLayout(vbox_load)
        layout.addWidget(grp_load)
        self.tab_excel.setLayout(layout)

    # --- 3. تبويب الرفع والمزامنة الثنائية ---
    def setup_push_tab(self):
        layout = QVBoxLayout()
        
        grp_map = QGroupBox("الطبقة المصدر (QGIS)")
        vbox_map = QVBoxLayout()
        row_map = QHBoxLayout()
        self.combo_push_layers = QComboBox()
        btn_refresh = QPushButton("تحديث")
        btn_refresh.clicked.connect(self.refresh_layers)
        row_map.addWidget(QLabel("الطبقة:"))
        row_map.addWidget(self.combo_push_layers)
        row_map.addWidget(btn_refresh)
        vbox_map.addLayout(row_map)
        grp_map.setLayout(vbox_map)
        layout.addWidget(grp_map)

        grp_acc = QGroupBox("قاعدة البيانات الهدف (Access)")
        vbox_acc = QVBoxLayout()
        
        row_acc = QHBoxLayout()
        acc_name = os.path.basename(self.push_access_path) if self.push_access_path else "لم يتم الاختيار"
        self.lbl_push_acc = QLabel(acc_name)
        btn_sel_acc = QPushButton("اختيار قاعدة البيانات")
        btn_sel_acc.clicked.connect(lambda: self.select_access_file('push'))
        row_acc.addWidget(btn_sel_acc)
        row_acc.addWidget(self.lbl_push_acc)
        vbox_acc.addLayout(row_acc)

        row_tbl = QHBoxLayout()
        self.combo_push_tables = QComboBox()
        self.combo_push_tables.currentTextChanged.connect(self.update_push_pk_combo)
        row_tbl.addWidget(QLabel("الجدول الهدف:"))
        row_tbl.addWidget(self.combo_push_tables)
        vbox_acc.addLayout(row_tbl)
        
        row_pk = QHBoxLayout()
        self.combo_push_pk = QComboBox()
        row_pk.addWidget(QLabel("المفتاح الأساسي للمطابقة (Primary Key):"))
        row_pk.addWidget(self.combo_push_pk)
        vbox_acc.addLayout(row_pk)

        # حل النزاعات
        row_conflict = QHBoxLayout()
        self.combo_conflict = QComboBox()
        self.combo_conflict.addItems(["أولوية لخريطة QGIS (تحديث Access)", "أولوية لقاعدة Access (تجاهل الخريطة)"])
        row_conflict.addWidget(QLabel("في حال تعارض البيانات:"))
        row_conflict.addWidget(self.combo_conflict)
        vbox_acc.addLayout(row_conflict)

        self.chk_sync_deletions = QCheckBox("مزامنة الحذف (حذف السجلات من Access إذا غير موجودة في الخريطة)")
        self.chk_sync_deletions.setStyleSheet("color: #D32F2F; font-weight: bold;")
        vbox_acc.addWidget(self.chk_sync_deletions)

        btn_push = QPushButton("إرسال التحديثات والمزامنة (معاينة قبل التنفيذ)")
        btn_push.setStyleSheet("background-color: #FF9800; color: white; font-weight: bold; padding: 12px;")
        btn_push.clicked.connect(self.prepare_push_data)
        vbox_acc.addWidget(btn_push)
        
        grp_acc.setLayout(vbox_acc)
        layout.addWidget(grp_acc)
        layout.addStretch()
        self.tab_push.setLayout(layout)

    # --- 4. تبويب الأتمتة (Auto-Sync) ---
    def setup_auto_tab(self):
        layout = QVBoxLayout()
        grp_auto = QGroupBox("المزامنة التلقائية في الخلفية")
        vbox_auto = QVBoxLayout()
        
        lbl_info = QLabel("تقوم هذه الميزة بمزامنة الطبقة المحددة مع قاعدة الأكسيس تلقائياً كل فترة زمنية بدون تدخل منك.")
        lbl_info.setStyleSheet("color: gray;")
        vbox_auto.addWidget(lbl_info)

        row_time = QHBoxLayout()
        self.txt_interval = QLineEdit("10")
        row_time.addWidget(QLabel("المدة بين كل مزامنة (بالدقائق):"))
        row_time.addWidget(self.txt_interval)
        vbox_auto.addLayout(row_time)

        self.btn_start_auto = QPushButton("▶️ تشغيل المزامنة التلقائية")
        self.btn_start_auto.setStyleSheet("background-color: #009688; color: white; font-weight: bold; padding: 10px;")
        self.btn_start_auto.clicked.connect(self.toggle_auto_sync)
        vbox_auto.addWidget(self.btn_start_auto)
        
        self.lbl_auto_status = QLabel("حالة الأتمتة: متوقفة")
        self.lbl_auto_status.setAlignment(Qt.AlignCenter)
        vbox_auto.addWidget(self.lbl_auto_status)

        grp_auto.setLayout(vbox_auto)
        layout.addWidget(grp_auto)
        layout.addStretch()
        self.tab_auto.setLayout(layout)

    # --- 5. تبويب الأدوات وصحة البيانات ---
    def setup_tools_tab(self):
        layout = QVBoxLayout()
        grp_layer = QGroupBox("اختيار الطبقة للأدوات")
        vbox_layer = QVBoxLayout()
        self.combo_tools_layers = QComboBox()
        self.combo_tools_layers.currentTextChanged.connect(self.update_tool_fields)
        vbox_layer.addWidget(self.combo_tools_layers)
        grp_layer.setLayout(vbox_layer)
        layout.addWidget(grp_layer)

        # صحة البيانات
        grp_health = QGroupBox("لوحة صحة البيانات (Data Health Dashboard)")
        vbox_health = QVBoxLayout()
        row_phone = QHBoxLayout()
        self.combo_phone_field = QComboBox()
        row_phone.addWidget(QLabel("اختر حقل الهاتف لفحصه:"))
        row_phone.addWidget(self.combo_phone_field)
        vbox_health.addLayout(row_phone)

        btn_health = QPushButton("📊 عرض تقرير صحة البيانات")
        btn_health.setStyleSheet("background-color: #673AB7; color: white; font-weight: bold;")
        btn_health.clicked.connect(self.show_data_health)
        vbox_health.addWidget(btn_health)
        grp_health.setLayout(vbox_health)
        layout.addWidget(grp_health)

        # التلوين التلقائي
        grp_symbology = QGroupBox("التلوين التلقائي للخريطة (Auto-Symbology)")
        vbox_sym = QVBoxLayout()
        row_sym = QHBoxLayout()
        self.combo_sym_field = QComboBox()
        row_sym.addWidget(QLabel("لوّن الخريطة بناءً على حقل:"))
        row_sym.addWidget(self.combo_sym_field)
        vbox_sym.addLayout(row_sym)
        btn_sym = QPushButton("🎨 تطبيق الألوان")
        btn_sym.clicked.connect(self.apply_auto_symbology)
        vbox_sym.addWidget(btn_sym)
        grp_symbology.setLayout(vbox_sym)
        layout.addWidget(grp_symbology)

        # تصدير KML
        grp_kml = QGroupBox("تصدير خرائط جوجل (Google My Maps)")
        vbox_kml = QVBoxLayout()
        btn_gmaps = QPushButton("تصدير (KML)")
        btn_gmaps.setStyleSheet("background-color: #0F9D58; color: white; font-weight: bold;")
        btn_gmaps.clicked.connect(self.export_to_kml)
        vbox_kml.addWidget(btn_gmaps)
        grp_kml.setLayout(vbox_kml)
        layout.addWidget(grp_kml)
        
        layout.addStretch()
        self.tab_tools.setLayout(layout)

    # --- 6. الترخيص ---
    def setup_license_tab(self):
        layout = QVBoxLayout()
        lbl_form = QLabel('<a href="https://script.google.com/macros/s/AKfycbydG8Y2sElgVvuQpbWUtsWHJS6t6-cIyL87dS4NGSszbA3O1ocKsXVlUVfCJyLZVrv8/exec" style="color: #2196F3; font-size: 14px; font-weight: bold; text-decoration: none;">طلب تفعيل النسخة المدفوعة</a>')
        lbl_form.setOpenExternalLinks(True)
        lbl_form.setAlignment(Qt.AlignCenter)
        layout.addWidget(lbl_form)

        grp_act = QGroupBox("التفعيل")
        frm = QFormLayout()
        self.txt_hwid = QLineEdit(self.hwid)
        self.txt_hwid.setReadOnly(True)
        frm.addRow("البصمة الإلكترونية (HWID):", self.txt_hwid)
        self.txt_key = QLineEdit()
        frm.addRow("الكود:", self.txt_key)
        btn_act = QPushButton("تفعيل")
        btn_act.clicked.connect(self.activate_license)
        frm.addWidget(btn_act)
        
        btn_chk = QPushButton("تحقق من السيرفر المباشر")
        btn_chk.clicked.connect(self.check_online_activation)
        frm.addWidget(btn_chk)
        
        grp_act.setLayout(frm)
        layout.addWidget(grp_act)

        self.lbl_status = QLabel("الحالة: " + ("✅ Pro" if self.is_pro else "⚠️ Free"))
        self.lbl_status.setAlignment(Qt.AlignCenter)
        self.lbl_status.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(self.lbl_status)
        layout.addStretch()
        self.tab_license.setLayout(layout)


    # ==========================================
    # دوال العمليات المساعدة والتراخيص
    # ==========================================
    def update_push_pk_combo(self):
        if not self.push_access_path: return
        tbl = self.combo_push_tables.currentText()
        if not tbl: return
        try:
            conn = pyodbc.connect(f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self.push_access_path};")
            cursor = conn.cursor()
            cols = [row.column_name for row in cursor.columns(table=tbl)]
            conn.close()
            self.combo_push_pk.clear()
            self.combo_push_pk.addItems(cols)
            for c in cols:
                if c.lower() in ["id", "customer_n", "uid", "code"]:
                    self.combo_push_pk.setCurrentText(c)
                    break
        except: pass

    def update_tool_fields(self):
        layer_name = self.combo_tools_layers.currentText()
        layers = QgsProject.instance().mapLayersByName(layer_name)
        self.combo_phone_field.clear()
        self.combo_sym_field.clear()
        if layers:
            fields = [f.name() for f in layers[0].fields()]
            self.combo_phone_field.addItems(fields)
            self.combo_sym_field.addItems(fields)

    def verify_online_license(self):
        if os.path.exists(self.license_file):
            with open(self.license_file, "r") as f:
                self.check_key_validity(f.read().strip())
        def send_log():
            try:
                urllib.request.urlopen(f"{self.google_api_url}?action=log&hwid={self.hwid}&status={'PRO' if self.is_pro else 'FREE'}", timeout=5)
            except: pass
        threading.Thread(target=send_log).start()

    def check_online_activation(self):
        try:
            req = urllib.request.urlopen(f"{self.google_api_url}?hwid={self.hwid}", timeout=5)
            res = json.loads(req.read().decode())
            if res.get("status") == "active":
                self.is_pro = True
                self.lbl_status.setText("الحالة: ✅ Pro")
                QMessageBox.information(self, "نجاح", "تم التفعيل من السيرفر.")
                return
        except: pass
        QMessageBox.warning(self, "فشل", "غير مفعل على السيرفر.")

    def check_key_validity(self, key):
        try:
            data = json.loads(base64.b64decode(key).decode("utf-8"))
            if data.get("hwid") == self.hwid and data.get("salt") == self.secret_salt:
                if datetime.now() <= datetime.strptime(data.get("expiry"), "%Y-%m-%d"):
                    self.is_pro = True
                    return True
        except: pass
        return False

    def activate_license(self):
        key = self.txt_key.text().strip()
        if self.check_key_validity(key):
            with open(self.license_file, "w") as f: f.write(key)
            QMessageBox.information(self, "نجاح", "تم التفعيل.")
        else:
            QMessageBox.critical(self, "خطأ", "الكود غير صحيح.")

    def select_access_file(self, target):
        path, _ = QFileDialog.getOpenFileName(self, "اختر قاعدة البيانات", "", "Access (*.accdb *.mdb)")
        if not path: return
        try:
            conn = pyodbc.connect(f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={path};")
            tables = [t.table_name for t in conn.cursor().tables(tableType="TABLE")]
            conn.close()
            if target == 'pull':
                self.pull_access_path = path
                self.settings.setValue("Aboelil/pull_path", path)
                self.lbl_pull_acc.setText(os.path.basename(path))
                self.combo_pull_tables.clear()
                self.combo_pull_tables.addItems(tables)
            elif target == 'push':
                self.push_access_path = path
                self.settings.setValue("Aboelil/push_path", path)
                self.lbl_push_acc.setText(os.path.basename(path))
                self.combo_push_tables.clear()
                self.combo_push_tables.addItems(tables)
                self.update_push_pk_combo()
        except pyodbc.Error as e:
            QMessageBox.critical(self, "خطأ", str(e))


    def show_table_summary(self):
        if not self.pull_access_path: 
            QMessageBox.warning(self, "تنبيه", "برجاء اختيار قاعدة بيانات أولاً.")
            return
        tbl = self.combo_pull_tables.currentText()
        if not tbl: return
        try:
            conn = pyodbc.connect(f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self.pull_access_path};")
            df = pd.read_sql(f"SELECT TOP 5 * FROM [{tbl}]", conn)
            conn.close()
            summary = f"الجدول: {tbl}\nعدد الأعمدة: {len(df.columns)}\n\n"
            for col in df.columns:
                summary += f"- {col} ({df[col].dtype})\n"
            msg = QMessageBox(self)
            msg.setWindowTitle("تفاصيل الحقول")
            msg.setText(summary)
            msg.exec_()
        except Exception as e:
            QMessageBox.critical(self, "خطأ", str(e))

            
    def refresh_layers(self):
        self.combo_push_layers.clear()
        self.combo_tools_layers.clear()
        self.combo_excel_target.clear()
        layers = [l.name() for l in QgsProject.instance().mapLayers().values() if l.type() == Qgis.LayerType.Vector]
        if layers:
            self.combo_push_layers.addItems(layers)
            self.combo_tools_layers.addItems(layers)
            self.combo_excel_target.addItems(layers)
            self.update_tool_fields()
        else:
            self.combo_push_layers.addItem("لا يوجد طبقات")
            self.combo_tools_layers.addItem("لا يوجد طبقات")
            self.combo_excel_target.addItem("لا يوجد طبقات")

    def detect_spatial_columns(self, columns):
        res = {"x": None, "y": None}
        pairs = [("longitude", "latitude"), ("lon", "lat"), ("x", "y"), ("lng", "lat")]
        for x_name, y_name in pairs:
            x_col = next((c for c in columns if x_name.lower() in str(c).lower()), None)
            y_col = next((c for c in columns if y_name.lower() in str(c).lower()), None)
            if x_col and y_col:
                res["x"] = x_col
                res["y"] = y_col
                return res
        return res

    def sanitize_val(self, val):
        if type(val).__name__ == "QVariant" or val == NULL or pd.isna(val) or str(val).strip() == "": return None
        if isinstance(val, QDate): return val.toString("yyyy-MM-dd")
        if isinstance(val, QDateTime): return val.toString("yyyy-MM-dd HH:mm:ss")
        if isinstance(val, (np.int64, np.int32)): return int(val)
        if isinstance(val, (np.float64, np.float32)): return float(val)
        return val

    def get_gdf_from_layer(self, layer_name):
        layers = QgsProject.instance().mapLayersByName(layer_name)
        if not layers: return None
        layer = layers[0]
        fields = [f.name() for f in layer.fields()]
        data = []
        for feat in layer.getFeatures():
            row = dict(zip(fields, feat.attributes()))
            geom = feat.geometry()
            row["geometry"] = wkt.loads(geom.asWkt()) if not geom.isNull() else None
            data.append(row)
        return gpd.GeoDataFrame(data, geometry="geometry") if data else gpd.GeoDataFrame()

    # ================== دوال السحب والرفع والإكسيل ==================
    def pull_data(self):
        if not self.pull_access_path: return
        path, _ = QFileDialog.getSaveFileName(self, "حفظ", "", "GeoPackage (*.gpkg)")
        if not path: return
        tbl = self.combo_pull_tables.currentText()
        
        # استخراج كود الـ EPSG من الـ Widget
        crs_auth_id = self.crs_selector.crs().authid()
        if not crs_auth_id: crs_auth_id = "EPSG:4326"

        self.progress.setValue(10)
        try:
            conn = pyodbc.connect(f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self.pull_access_path};")
            df = pd.read_sql(f"SELECT * FROM [{tbl}]", conn)
            conn.close()
            
            if not self.is_pro and len(df) > 50: df = df.head(50)
            
            spatial = self.detect_spatial_columns(df.columns)
            if spatial["x"] and spatial["y"]:
                x, y = spatial["x"], spatial["y"]
                df[x] = pd.to_numeric(df[x], errors='coerce')
                df[y] = pd.to_numeric(df[y], errors='coerce')
                df["geometry"] = df.apply(lambda r: Point(r[x], r[y]) if pd.notnull(r[x]) and pd.notnull(r[y]) else None, axis=1)
                
            if self.chk_ignore_nulls.isChecked() and "geometry" in df.columns:
                df = df.dropna(subset=["geometry"])
                
            gdf = gpd.GeoDataFrame(df, geometry="geometry" if "geometry" in df.columns else None, crs=crs_auth_id)
            gdf.to_file(path, layer=tbl, driver="GPKG")
            
            vlayer = QgsVectorLayer(f"{path}|layername={tbl}", tbl, "ogr")
            if vlayer.isValid():
                QgsProject.instance().addMapLayer(vlayer)
                self.refresh_layers()
                
            self.progress.setValue(100)
            QMessageBox.information(self, "نجاح", f"تم السحب بنظام {crs_auth_id} بنجاح. ({len(df)} سجل)")
        except Exception as e:
            QMessageBox.critical(self, "خطأ", str(e))
            self.progress.setValue(0)

    # --- الماتشينج للإكسيل ---
    def clear_mapping_layout(self):
        while self.mapping_layout.count():
            child = self.mapping_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        self.mapping_combos.clear()

    def load_excel_for_mapping(self):
        layer_name = self.combo_excel_target.currentText()
        layers = QgsProject.instance().mapLayersByName(layer_name)
        if not layers or layer_name == "لا يوجد طبقات":
            QMessageBox.warning(self, "تنبيه", "برجاء اختيار طبقة صحيحة أولاً لدمج البيانات بها.")
            return
            
        path, _ = QFileDialog.getOpenFileName(self, "اختر Excel", "", "Excel (*.xlsx *.xls)")
        if not path: return
        self.progress.setValue(20)
        QApplication.processEvents()

        try:
            self.current_excel_df = pd.read_excel(path)
            excel_cols = ["-- تجاهل --"] + list(self.current_excel_df.columns)
            self.clear_mapping_layout()
            
            spatial_guess = self.detect_spatial_columns(self.current_excel_df.columns)
            self.x_combo = QComboBox()
            self.x_combo.addItems(excel_cols)
            self.x_combo.setStyleSheet("background-color: #E3F2FD; font-weight: bold;")
            if spatial_guess["x"]: self.x_combo.setCurrentText(spatial_guess["x"])
            
            self.y_combo = QComboBox()
            self.y_combo.addItems(excel_cols)
            self.y_combo.setStyleSheet("background-color: #E3F2FD; font-weight: bold;")
            if spatial_guess["y"]: self.y_combo.setCurrentText(spatial_guess["y"])

            self.mapping_layout.addRow("📍 خط الطول (X):", self.x_combo)
            self.mapping_layout.addRow("📍 خط العرض (Y):", self.y_combo)
            
            sep = QLabel("--- مطابقة حقول البيانات ---")
            sep.setStyleSheet("font-weight: bold; color: gray; margin-top: 10px;")
            sep.setAlignment(Qt.AlignCenter)
            self.mapping_layout.addRow(sep)

            target_layer = layers[0]
            fields = target_layer.fields()
            for field in fields:
                fname = field.name()
                ftype = field.typeName()
                cb = QComboBox()
                cb.addItems(excel_cols)
                for col in self.current_excel_df.columns:
                    if str(col).lower() == fname.lower():
                        cb.setCurrentText(col)
                        break
                self.mapping_combos[fname] = cb
                self.mapping_layout.addRow(f"[{ftype}] {fname} <==", cb)

            self.btn_execute_excel.setEnabled(True)
            self.progress.setValue(100)
        except Exception as e:
            QMessageBox.critical(self, "خطأ", f"فشل في قراءة الإكسيل: {str(e)}")
            self.progress.setValue(0)

    def execute_excel_import(self):
        if self.current_excel_df is None: return
        layer_name = self.combo_excel_target.currentText()
        target_layer = QgsProject.instance().mapLayersByName(layer_name)[0]
        
        x_col = self.x_combo.currentText()
        y_col = self.y_combo.currentText()
        if x_col == "-- تجاهل --" or y_col == "-- تجاهل --":
            QMessageBox.warning(self, "تنبيه", "يجب تحديد عواميد الإحداثيات.")
            return

        self.progress.setValue(10)
        df = self.current_excel_df.copy()
        df[x_col] = pd.to_numeric(df[x_col], errors='coerce')
        df[y_col] = pd.to_numeric(df[y_col], errors='coerce')
        
        target_layer.startEditing()
        provider = target_layer.dataProvider()
        fields = target_layer.fields()
        field_info = {f.name(): f.typeName().lower() for f in fields}
        
        features = []
        for idx, row in df.iterrows():
            x_val = row[x_col]
            y_val = row[y_col]
            if pd.isna(x_val) or pd.isna(y_val): continue
                
            feat = QgsFeature(fields)
            for f_name, cb in self.mapping_combos.items():
                excel_col = cb.currentText()
                if excel_col == "-- تجاهل --": continue
                
                val = row.get(excel_col)
                if pd.notna(val):
                    target_type = field_info.get(f_name, "")
                    try:
                        if 'real' in target_type or 'double' in target_type:
                            clean_val = float(str(val).replace(',', ''))
                        elif 'int' in target_type:
                            clean_val = int(float(str(val).replace(',', '')))
                        elif 'string' in target_type or 'text' in target_type:
                            if isinstance(val, float) and val.is_integer():
                                clean_val = str(int(val))
                            else:
                                clean_val = str(val)
                        else:
                            clean_val = self.sanitize_val(val)
                        feat.setAttribute(f_name, clean_val)
                    except Exception: continue
                        
            geom = QgsGeometry.fromPointXY(QgsPointXY(float(x_val), float(y_val)))
            feat.setGeometry(geom)
            features.append(feat)
            
        if features:
            provider.addFeatures(features)
            target_layer.commitChanges()
            target_layer.updateExtents()
            target_layer.triggerRepaint()
            
        self.progress.setValue(100)
        QMessageBox.information(self, "نجاح", f"تم دمج {len(features)} نقطة بنجاح مع مطابقة البيانات!")
        self.btn_execute_excel.setEnabled(False)

    # --- الرفع وحل النزاعات ---
    def prepare_push_data(self):
        if not self.push_access_path:
            QMessageBox.warning(self, "تنبيه", "اختر قاعدة بيانات الأكسيس أولاً.")
            return
        lname = self.combo_push_layers.currentText()
        tbl = self.combo_push_tables.currentText()
        pk_col = self.combo_push_pk.currentText()
        conflict_choice = self.combo_conflict.currentIndex() # 0 = QGIS wins, 1 = Access wins

        if lname == "لا يوجد طبقات" or not tbl or not pk_col: return
        layers = QgsProject.instance().mapLayersByName(lname)
        if layers and layers[0].isEditable():
            QMessageBox.warning(self, "تنبيه", "أغلق قلم التعديل في QGIS أولاً.")
            return

        self.progress.setValue(10)
        QApplication.processEvents()

        try:
            gdf = self.get_gdf_from_layer(lname)
            if gdf.empty: return
            
            conn = pyodbc.connect(f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self.push_access_path};")
            df_acc = pd.read_sql(f"SELECT [{pk_col}] FROM [{tbl}]", conn)
            acc_keys = set(df_acc[pk_col].astype(str).tolist())
            conn.close()

            update_list = []
            insert_list = []
            qgis_keys = set()
            
            self.progress.setValue(30)
            
            for _, row in gdf.iterrows():
                rid = str(row.get(pk_col, ''))
                if rid == 'None' or not rid: continue
                qgis_keys.add(rid)
                
                geom = row.get("geometry")
                lat = lon = None
                if geom and pd.notnull(geom):
                    lon, lat = geom.centroid.x, geom.centroid.y
                if self.chk_ignore_nulls.isChecked() and not geom: continue
                
                if rid in acc_keys:
                    # لو الاختيار للأكسيس، لا تقم بتحديث السجلات الموجودة مسبقاً (حل نزاع)
                    if conflict_choice == 0: 
                        update_list.append((lat, lon, rid))
                else:
                    insert_list.append((rid, lat, lon))
            
            delete_list = []
            if self.chk_sync_deletions.isChecked():
                for ak in acc_keys:
                    if str(ak) not in qgis_keys:
                        delete_list.append((str(ak),))

            self.progress.setValue(80)

            msg = f"معاينة العمليات على جدول ({tbl}):\n\n"
            msg += f"🟢 سيتم إضافة: {len(insert_list)} عميل جديد\n"
            msg += f"🟡 سيتم تحديث: {len(update_list)} عميل حالي\n"
            if self.chk_sync_deletions.isChecked():
                msg += f"🔴 سيتم حذف: {len(delete_list)} عميل مفقود من الخريطة\n"
            msg += "\nهل توافق على رفع هذه التعديلات لقاعدة البيانات؟"

            reply = QMessageBox.question(self, 'تأكيد الرفع', msg, QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.progress.setValue(90)
                self.worker = ExecuteDBWorker(self.push_access_path, tbl, pk_col, update_list, insert_list, delete_list)
                self.worker.progress_sig.connect(self.progress.setValue)
                self.worker.finished_sig.connect(self.on_push_finished)
                self.worker.start()
            else:
                self.progress.setValue(0)
        except Exception as e:
            QMessageBox.critical(self, "خطأ", str(e))
            self.progress.setValue(0)

    def on_push_finished(self, success, msg):
        if success:
            QMessageBox.information(self, "نجاح", msg)
        else:
            QMessageBox.critical(self, "خطأ", msg)
        self.progress.setValue(0)

    # --- الأتمتة (Auto-Sync) ---
    def toggle_auto_sync(self):
        if not self.is_pro:
            QMessageBox.warning(self, "تنبيه", "هذه الميزة متاحة فقط للنسخة المدفوعة Pro.")
            return

        if self.auto_sync_timer.isActive():
            self.auto_sync_timer.stop()
            self.btn_start_auto.setText("▶️ تشغيل المزامنة التلقائية")
            self.btn_start_auto.setStyleSheet("background-color: #009688; color: white; font-weight: bold; padding: 10px;")
            self.lbl_auto_status.setText("حالة الأتمتة: متوقفة")
            self.lbl_auto_status.setStyleSheet("color: red;")
        else:
            minutes = int(self.txt_interval.text())
            if minutes < 1: minutes = 1
            self.auto_sync_timer.start(minutes * 60 * 1000)
            self.btn_start_auto.setText("⏹️ إيقاف المزامنة التلقائية")
            self.btn_start_auto.setStyleSheet("background-color: #E53935; color: white; font-weight: bold; padding: 10px;")
            self.lbl_auto_status.setText(f"حالة الأتمتة: قيد التشغيل (كل {minutes} دقائق)")
            self.lbl_auto_status.setStyleSheet("color: green; font-weight: bold;")
            QMessageBox.information(self, "بدء", "تم تشغيل المزامنة التلقائية في الخلفية بناءً على إعدادات الرفع الحالية.")

    def perform_silent_sync(self):
        # دالة صامتة تعمل في الخلفية بدون نوافذ تأكيد
        if not self.push_access_path: return
        lname = self.combo_push_layers.currentText()
        tbl = self.combo_push_tables.currentText()
        pk_col = self.combo_push_pk.currentText()
        if lname == "لا يوجد طبقات" or not tbl or not pk_col: return
        
        try:
            gdf = self.get_gdf_from_layer(lname)
            if gdf.empty: return
            
            conn = pyodbc.connect(f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self.push_access_path};")
            df_acc = pd.read_sql(f"SELECT [{pk_col}] FROM [{tbl}]", conn)
            acc_keys = set(df_acc[pk_col].astype(str).tolist())
            conn.close()

            update_list = []
            insert_list = []
            for _, row in gdf.iterrows():
                rid = str(row.get(pk_col, ''))
                if rid == 'None' or not rid: continue
                geom = row.get("geometry")
                lat = lon = None
                if geom and pd.notnull(geom):
                    lon, lat = geom.centroid.x, geom.centroid.y
                if rid in acc_keys: update_list.append((lat, lon, rid))
                else: insert_list.append((rid, lat, lon))
            
            # تنفيذ صامت عبر الثريد
            self.worker = ExecuteDBWorker(self.push_access_path, tbl, pk_col, update_list, insert_list, [])
            self.worker.start()
            QgsMessageLog.logMessage(f"Auto-Sync Completed: {datetime.now()}", "Aboelil Sync", Qgis.Info)
        except Exception as e:
            QgsMessageLog.logMessage(f"Auto-Sync Failed: {str(e)}", "Aboelil Sync", Qgis.Critical)

    # --- أدوات صحة البيانات والتلوين ---
    def show_data_health(self):
        lname = self.combo_tools_layers.currentText()
        phone_field = self.combo_phone_field.currentText()
        gdf = self.get_gdf_from_layer(lname)
        if gdf is None or gdf.empty: return
        
        total = len(gdf)
        null_geom = gdf['geometry'].isna().sum()
        
        gdf['coords'] = gdf['geometry'].apply(lambda g: f"{g.centroid.x},{g.centroid.y}" if g else None)
        dup_coords = gdf.duplicated(subset=['coords']).sum() - null_geom # لا نحسب الـ nulls كمكررات
        if dup_coords < 0: dup_coords = 0
        
        dup_phones = 0
        if phone_field and phone_field in gdf.columns:
            dup_phones = gdf.duplicated(subset=[phone_field]).sum()
            
        report = f"""
        📊 تقرير صحة البيانات للطبقة ({lname}):
        ------------------------------------
        🔹 إجمالي السجلات: {total}
        
        📍 سجلات بدون موقع (فارغة): {null_geom}
        ⚠️ إحداثيات مكررة (فوق بعض): {dup_coords}
        📞 أرقام هواتف مكررة: {dup_phones}
        """
        QMessageBox.information(self, "صحة البيانات", report)

    def apply_auto_symbology(self):
        lname = self.combo_tools_layers.currentText()
        field = self.combo_sym_field.currentText()
        if not field: return
        
        layers = QgsProject.instance().mapLayersByName(lname)
        if not layers: return
        layer = layers[0]
        
        unique_vals = layer.uniqueValues(layer.fields().indexOf(field))
        categories = []
        for val in unique_vals:
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())
            # تلوين عشوائي متناسق
            symbol.setColor(QColor(random.randint(50, 255), random.randint(50, 255), random.randint(50, 255)))
            category = QgsRendererCategory(val, symbol, str(val))
            categories.append(category)
            
        renderer = QgsCategorizedSymbolRenderer(field, categories)
        layer.setRenderer(renderer)
        layer.triggerRepaint()
        QMessageBox.information(self, "نجاح", f"تم تلوين الخريطة تلقائياً بناءً على الحقل: {field}")

    def export_to_kml(self):
        lname = self.combo_tools_layers.currentText()
        layers = QgsProject.instance().mapLayersByName(lname)
        if not layers: return
        
        path, _ = QFileDialog.getSaveFileName(self, "حفظ KML", "", "KML (*.kml)")
        if not path: return
        try:
            QgsVectorFileWriter.writeAsVectorFormatV2(layers[0], path, QgsProject.instance().transformContext(), QgsVectorFileWriter.SaveVectorOptions())
            msg = QMessageBox(self)
            msg.setWindowTitle("تم التصدير")
            msg.setText("تم إنشاء الملف بنجاح.")
            msg.setInformativeText('<a href="https://www.google.com/maps/d/">اضغط هنا لفتح Google My Maps وعمل استيراد للملف</a>')
            msg.setTextFormat(Qt.RichText)
            msg.exec_()
        except Exception as e:
            QMessageBox.critical(self, "خطأ", str(e))