import sys
import os

# السطرين دول هما السر عشان QGIS يشوف فولدر التشفير (pyarmor_runtime)
plugin_dir = os.path.dirname(__file__)
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)

def classFactory(iface):
    from .aboelil_plugin import AboelilPlugin
    return AboelilPlugin(iface)