import sys
from qgis.PyQt.QtWidgets import QMessageBox

def classFactory(iface):
    # فحص إصدار بايثون (لو أقدم من 3.12)
    if sys.version_info < (3, 12):
        msg = (
            "⚠️ أداة (Aboelil GeoAccess Sync) تتطلب بيئة عمل أحدث.\n\n"
            "إصدار QGIS الحالي لديك يستخدم نسخة Python قديمة وغير متوافقة مع محرك الأداة.\n"
            "برجاء تحديث برنامج QGIS إلى أحدث إصدار لضمان عمل الأداة بنجاح."
        )
        QMessageBox.critical(None, "إصدار غير مدعوم - Aboelil Tools", msg)
        
        class DummyPlugin:
            def __init__(self, iface): pass
            def initGui(self): pass
            def unload(self): pass
        return DummyPlugin(iface)

    # لو الإصدار حديث وسليم، شغل الأداة المشفرة
    from .aboelil_plugin import AboelilPlugin
    return AboelilPlugin(iface)