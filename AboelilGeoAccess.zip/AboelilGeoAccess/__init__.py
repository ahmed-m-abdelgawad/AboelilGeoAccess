def classFactory(iface):
    from .aboelil_plugin import AboelilPlugin
    return AboelilPlugin(iface)